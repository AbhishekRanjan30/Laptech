﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class newproductentry : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        bool b = LoginManager.IsUserLoggedIn(Session);
        if (!b)
            Response.Redirect("login.aspx");
    }
    protected void btsubmit_Click(object sender, EventArgs e)
    {
        try
        {
            String modelno;
            int vendorno, brandno;
            float price, discount;

            brandno = Convert.ToInt32(ddbrand.SelectedValue);
            modelno = txtmodelno.Text;
            vendorno = VendorUtilities.GetVendornobyname(LoginManager.currentuser(Session));
            price = (float)Convert.ToDouble(txtprice.Text);
            discount = (float)Convert.ToDouble(txtdiscounts.Text);

            DataSet1TableAdapters.productsTableAdapter da = new DataSet1TableAdapters.productsTableAdapter();
            da.Insert(brandno, modelno, vendorno, price, discount);

            btnext.Enabled = true;
            btsubmit.Enabled = false;
            //Response.Redirect("productspecificationsentry.aspx?pno="+productUtilities.getLastProductNo());

        }

        catch (Exception x)
        {
            Title = x.Message;
        }
    }
    protected void btreset_Click(object sender, EventArgs e)
    {
        Validations.totalResetTextboxs(txtprice, txtmodelno, txtdiscounts);
    }
    protected void btnext_Click(object sender, EventArgs e)
    {
        Response.Redirect("productspecificationsentry.aspx?pno=" + productUtilities.getLastProductNo());
    }
}