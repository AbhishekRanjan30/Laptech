﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class productspecification : System.Web.UI.Page
{
    int productno;
    protected void Page_Load(object sender, EventArgs e)
    {
        productno = Convert.ToInt32(Request.QueryString["pno"]);
        products p=new products(productno);
        List<string> images = productdisplay.getAllImages(productno);
        for (int i = 0; i < images.Count; i++)
        {
            allImages.InnerHtml += "<img src='" + images[i] + "' onmouseover='changeImage(\""+images[i]+"\")' alt='images' width='100%'/><br />";
        }
        string output = "";
        output += "<label class='w3-xlarge w3-margin-left rainbowText' id='lblbrandname'><b>"+products.GetBrandNameByBrandNo(p.brandno)+" "+p.modelno+"</b></label><br /><div class='w3-amber w3-circle' style='height:3px'>&nbsp;</div>";
        imagebig.Src = images[0];
        List<List<string>> allSpecifications = productSpecifications.GetProductSpecifications(productno);
        List<string> attName = allSpecifications[0];
        List<string> attValue = allSpecifications[1];
        
        for (int i = 0; i < attName.Count; i++)
        {
            output += "<div class='w3-row w3-center'><label class='w3-col s4 w3-center'><b>" + attName[i] + "</b></label><label class='w3-col s4 w3-center'>" + attValue[i] + "</label></div><br />";
        }
        if (p.discount == 0)
        {
            output += "<br /><b>Price <i class='fa fa-rupee-sign'></i> " + p.price + "</b><br /><br />";
        }
        else
        {
            output += "<br /><b>Price <label style='text-decoration:line-through' class='w3-text-grey'><i class='fa fa-rupee-sign'></i>" + p.price + "</label>&nbsp;&nbsp;<i class='fa fa-rupee-sign'></i> " + (p.price - p.discount) + "</b><i class='w3-text-grey'>&nbsp;(Save Rs. "+p.discount+"/-)</i><br /><br />";
        }
        output += "<div class='w3-row w3-center'><button id='btbuy' runat='server' onclick='disp' class='w3-button w3-padding w3-col s4 w3-orange w3-hover-black w3-round-xlarge zoom'><i class='fa fa-rupee-sign'></i>&nbsp;<b>Buy Now</b></button>";
        output += "<div class='w3-col s1'>&nbsp;</div><button id='btcart' class='w3-button w3-padding w3-col s4 w3-green w3-hover-black w3-round-xlarge zoom'><i class='fa fa-cart-plus'></i>&nbsp;<b>Add To Cart</b></button></div>";
        details.InnerHtml = output;
    }

    public void disp(object sender, EventArgs e)
    {
        
    }
}