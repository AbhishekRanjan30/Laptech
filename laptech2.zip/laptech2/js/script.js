﻿var btCart;
function addInCart(pno) {
    btCart = document.getElementById("btcart" + pno);
    var req = new XMLHttpRequest();
    var url = "addToCart.aspx?pno=" + pno;
    req.open("GET", url, true);
    req.onreadystatechange = function () { result(req) };
    req.send();
    btCart.innerHTML = "<i class='fa fa-circle-notch fa-spin'></i>";
}
function result(req) {
    if (req.readyState != 4) {
        return;
    }
    var a = req.responseText.toString();
    if (a == 'Error') {
        alert("Error Adding Product To Cart");
        btCart.innerHTML = "<i class='fa fa-cart-plus'></i>&nbsp;<b>Add To Cart</b>";
    }
    else if (a == 'Success') {
        btCart.innerHTML = "<i class='fa fa-check'></i>&nbsp;<b>Item In Cart</b>";
    }
    else {
        btCart.innerHTML = "<i class='fa fa-cart-plus'></i>&nbsp;<b>Add To Cart</b>";
        document.getElementById("goto").click();
    }
}

function increaseQuantity(pno) {
    
}
