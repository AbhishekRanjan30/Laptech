﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class check : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btsubmit_Click(object sender, EventArgs e)
    {
        try
        {
            string number = txtnumber.Text;
            if(number.Length<10)
                throw new Exception("hgdghdhtgf");

        double no;
        no =Convert.ToDouble(txtnumber.Text);
        
        if (no < 5999999999)
            throw new Exception("Please Insert");
           
        lblmain.Text = "Insert Successfull";
        }
            

        catch(Exception x)

        {
            lblmain.Text = x.Message;
        }

    }
}