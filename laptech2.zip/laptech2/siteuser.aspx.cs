﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class siteuser : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnreg_Click(object sender, EventArgs e)
    {
        try
        {
            int usertypeno;
            DataSet1TableAdapters.usertypeTableAdapter db = new DataSet1TableAdapters.usertypeTableAdapter();
            usertypeno = (int)db.GetUserSno();
            

            string name,gender, email, userid, password, address;
            long contact;
            
            name = txtname.Text;
            if (name.Equals(""))
                {
                    throw new Exception("Please Enter Your Name");
                }

            gender =rdgender.SelectedValue;
            if (gender.Equals(""))
                {
                     throw new Exception("Please Enter Your Gender");
                 }

            email = txtemail.Text;
            if (email.Equals(""))
                 {
                     throw new Exception("Please Enter Email-Id");
                 }

            userid = txtuserid.Text;
            if (userid.Equals(""))
                {
                    throw new Exception("Please Enter UserID");
                 }

            
             password   = txtpassword.Text;
            if (password.Equals(""))
                 {
                    throw new Exception("Please Enter Your Password");
                 }

            address = txtaddress.Text;
            if (address.Equals(""))
            {
                throw new Exception("Please Enter Your Address");
            }

            contact = Convert.ToInt64(txtcontact.Text);
                if (contact < 5999999999)
                {
                throw new Exception("Please insert valid Number");
                }
                if (contact==0||contact==null)
                {
                    throw new Exception("Please Enter Your Contact");
                }
               


            DataSet1TableAdapters.siteuserTableAdapter da = new DataSet1TableAdapters.siteuserTableAdapter();
            da.Insert(name,gender,email,userid,password,""+contact,usertypeno,"Active",address);
            

            lblmain.Text = "Successfully Registered";
          

        }
        catch (Exception x)
        {
            lblmain.Text = x.Message;
        }

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Validations.totalResetTextboxs(txtname, txtcontact, txtaddress, txtemail, txtuserid, txtpassword);
    }
}