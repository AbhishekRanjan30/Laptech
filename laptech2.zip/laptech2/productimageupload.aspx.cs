﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;

public partial class productimageupload : System.Web.UI.Page
{
    int productno;
    protected void Page_Load(object sender, EventArgs e)
    {
        productno = Convert.ToInt32(Request.QueryString["pno"]);
        bool b = LoginManager.IsUserLoggedIn(Session);
        if (!b)
            Response.Redirect("login.aspx");
    }
    protected void btupload_Click(object sender, EventArgs e)
    {
        try
        {
            string folder = Server.MapPath("productImages\\" + productno);
            DataSet1TableAdapters.productimageTableAdapter da = new DataSet1TableAdapters.productimageTableAdapter();
            if (!Directory.Exists(folder))
            {
                Directory.CreateDirectory(folder);
            }
            HttpFileCollection files = Request.Files;
            for (int i = 0; i < files.Count; i++)
            {
                HttpPostedFile posted = files[i];
                string filesname = posted.FileName;
                if (!File.Exists(folder + "\\" + filesname))
                {
                    posted.SaveAs(folder + "\\" + filesname);
                    da.Insert(productno, "productImages/"+productno+"/" + filesname);
                }
                else
                {
                    //lblMessage.Text += filesname + " already exists.<br/>";
                }
            }
            Response.Redirect("VendorDashBoard.aspx");
            //lblMessage.Text += "Saved " + counter + "file(s)";
        }
        catch (Exception ex)
        {
            //lblMessage.Text = "" + ex.Message;
        }
    }
}