﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class newproducts : System.Web.UI.Page
{
    int productno;

    protected void Page_Load(object sender, EventArgs e)
    {
        productno = Convert.ToInt32(Request.QueryString["pno"]);
        bool b = LoginManager.IsUserLoggedIn(Session);
        if (!b)
            Response.Redirect("login.aspx");
    }
    protected void btsubmit_Click(object sender, EventArgs e)
    {
        String attributename, attributevalue;

        attributename = txtattributename.Text;
        attributevalue = txtattributevlaue.Text;

        DataSet1TableAdapters.specifictaionsTableAdapter da = new DataSet1TableAdapters.specifictaionsTableAdapter();
        da.Insert(productno, attributename, attributevalue);

        btnext.Enabled = true;
        GridView1.DataBind();
    }
    protected void btnext_Click(object sender, EventArgs e)
    {
        Response.Redirect("productimageupload.aspx?pno="+productno);
    }
}