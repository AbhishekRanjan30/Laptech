﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class index : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        bool b = LoginManager.IsUserLoggedIn(Session);
        if (b)
        {
            Button btlogin = (Button)Master.FindControl("btlogin") as Button;
            btlogin.Visible = false;
            Button btlogout = (Button)Master.FindControl("btlogout") as Button;
            btlogout.Visible = true;
        }

        if (!this.IsPostBack)
        {
          DataSet1TableAdapters.productsTableAdapter da = new DataSet1TableAdapters.productsTableAdapter();
            DataSet1.productsDataTable dt = da.GetData();
            for (int i = 0; i < dt.Count; i++)
            {
                DataSet1.productsRow dr = (DataSet1.productsRow)dt.Rows[i];
                productslist.InnerHtml += ""+productdisplay.productsDiv(dr.sno,Session);
            }
            string output = "";
            List<List<string>> brandsData = brandUtilities.GetAllBrands();
            List<string> brandName = brandsData[0];
            List<string> brandImage = brandsData[1];
            for (int i = 0; i < brandName.Count; i++)
            {
                string floatleft = "";
                if (i <= brandName.Count - 2)
                    floatleft = " style='float:left'";
                else
                    floatleft = " style='float:none'";
                output += "<div class='w3-padding' "+floatleft+"><div class='w3-round-xxlarge w3-padding'><img src='"+brandImage[i]+"' class='w3-circle' width='50px'/><b>"+brandName[i]+"</b></div></div>";
            }
            brands.InnerHtml = output;
        }
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        int value = Convert.ToInt32(drpFilter.SelectedValue);
        if (value == 0)
            return;
        if (value == 1)
        {
            brandfilter.Visible = true;
            ramfilter.Visible = false;
            pricefilter.Visible = false;
            godiv.Visible = false;
        }
        if (value == 2)
        {
            brandfilter.Visible = false;
            ramfilter.Visible = true;
            pricefilter.Visible = false;
            godiv.Visible = false;
        }
        if (value == 3)
        {
            brandfilter.Visible = false;
            ramfilter.Visible = false;
            pricefilter.Visible = true;
            godiv.Visible = true;
        }
    }
    protected void drpDwnSortBy_SelectedIndexChanged(object sender, EventArgs e)
    {
        int value = Convert.ToInt32(drpDwnSortBy.SelectedValue);
        if (value == 0)
        {
            return;
        }
        if (value == 1)
        {
            SortPriceLowToHigh();
            return;
        }
        if (value == 2)
        {
            SortPriceHighToLow();
            return;
        }
        if (value == 3)
        {
            SortNewest();
            return;
        }
        if (value == 4)
        {
            SortOldest();
            return;
        }

    }

    public void SortPriceLowToHigh()
    {
        productslist.InnerHtml = "";
        DataSet1TableAdapters.productsTableAdapter da = new DataSet1TableAdapters.productsTableAdapter();
        DataSet1.productsDataTable dt = da.PriceLowToHigh();
        for (int i = 0; i < dt.Count; i++)
        {
            DataSet1.productsRow dr = (DataSet1.productsRow)dt.Rows[i];
            productslist.InnerHtml += "" + productdisplay.productsDiv(dr.sno,Session);
        }
    }

    public void SortPriceHighToLow()
    {
        productslist.InnerHtml = "";
        DataSet1TableAdapters.productsTableAdapter da = new DataSet1TableAdapters.productsTableAdapter();
        DataSet1.productsDataTable dt = da.PriceHighToLow();
        for (int i = 0; i < dt.Count; i++)
        {
            DataSet1.productsRow dr = (DataSet1.productsRow)dt.Rows[i];
            productslist.InnerHtml += "" + productdisplay.productsDiv(dr.sno, Session);
        }
    }

    public void SortNewest()
    {
        productslist.InnerHtml = "";
        DataSet1TableAdapters.productsTableAdapter da = new DataSet1TableAdapters.productsTableAdapter();
        DataSet1.productsDataTable dt = da.GetData();
        for (int i = 0; i < dt.Count; i++)
        {
            DataSet1.productsRow dr = (DataSet1.productsRow)dt.Rows[i];
            productslist.InnerHtml += "" + productdisplay.productsDiv(dr.sno, Session);
        }
    }

    public void SortOldest()
    {
        productslist.InnerHtml = "";
        DataSet1TableAdapters.productsTableAdapter da = new DataSet1TableAdapters.productsTableAdapter();
        DataSet1.productsDataTable dt = da.GetOldestFirst();
        for (int i = 0; i < dt.Count; i++)
        {
            DataSet1.productsRow dr = (DataSet1.productsRow)dt.Rows[i];
            productslist.InnerHtml += "" + productdisplay.productsDiv(dr.sno, Session);
        }
    }
    protected void brandfilter_SelectedIndexChanged(object sender, EventArgs e)
    {
        int value = Convert.ToInt32(brandfilter.SelectedValue);
        if (value == 0)
        {
            return;
        }
        choosebrand(value);
    }
    public void choosebrand(int brandno)
    {
        productslist.InnerHtml = "";
        DataSet1TableAdapters.productsTableAdapter da = new DataSet1TableAdapters.productsTableAdapter();
        DataSet1.productsDataTable dt = da.GetDataByBrandNo(brandno);
        for (int i = 0; i < dt.Count; i++)
        {
            DataSet1.productsRow dr = (DataSet1.productsRow)dt.Rows[i];
            productslist.InnerHtml += "" + productdisplay.productsDiv(dr.sno, Session);
        }

    }
    protected void ramfilter_SelectedIndexChanged(object sender, EventArgs e)
    {
        string value = ""+ramfilter.SelectedValue;
        if (value.Equals("0"))
            return;
        chooseram(value);
    }
    public void chooseram(string ram)
    {
        productslist.InnerHtml = "";
        DataSet1TableAdapters.productsTableAdapter da = new DataSet1TableAdapters.productsTableAdapter();
        DataSet1.productsDataTable dt = da.GetProductByRAM(ram);
        for (int i = 0; i < dt.Count; i++)
        {
            DataSet1.productsRow dr = (DataSet1.productsRow)dt.Rows[i];
            productslist.InnerHtml += "" + productdisplay.productsDiv(dr.sno, Session);
        }
    }

    protected void btgo_Click(object sender, EventArgs e)
    {
        float from = (float)Convert.ToDouble(txtpricefrom.Text);
        float to= (float)Convert.ToDouble(txtpriceto.Text);
        if (from.Equals("") || from.Equals(null) || to.Equals("") || to.Equals(null))
        {
            return;
        }
        priceFilteredDisplay(from, to);
    }
    public void priceFilteredDisplay(float from, float to)
    {
        productslist.InnerHtml = "";
        DataSet1TableAdapters.productsTableAdapter da = new DataSet1TableAdapters.productsTableAdapter();
        DataSet1.productsDataTable dt = da.GetProductByPriceFilter(from, to);
        for (int i = 0; i < dt.Count; i++)
        {
            DataSet1.productsRow dr = (DataSet1.productsRow)dt.Rows[i];
            productslist.InnerHtml += "" + productdisplay.productsDiv(dr.sno, Session);
        }
    }
}