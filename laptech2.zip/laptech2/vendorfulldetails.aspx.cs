﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class vendorfulldetails : System.Web.UI.Page
{
    int sno;
    protected void Page_Load(object sender, EventArgs e)
    {

        sno = Convert.ToInt32(Request.QueryString["sno"]);

        DataSet1TableAdapters.vendorappliedlistTableAdapter da = new DataSet1TableAdapters.vendorappliedlistTableAdapter();
        DataSet1.vendorappliedlistDataTable dr = da.GetDataBySerialNo(sno);
        DataSet1.vendorappliedlistRow dt = (DataSet1.vendorappliedlistRow)dr.Rows[0];

        txtname.Text = dt.name;
        txtdob.Text =""+ dt.dob;
        txtgender.Text = dt.gender;
        txtstate.Text = dt.state;
        txtcontactno.Text = dt.contactno;
        txtemail.Text = dt.email;
        txtcompanyname.Text = dt.companyname;
        txtcompanyemail.Text = dt.companyemail;
        txtcompanyaddress.Text = dt.companyaddress;
        txtgstno.Text = dt.gstin;
        txtregno.Text = dt.registrationno;
        txtcompanycontactno.Text = dt.companycontactno;
         

        
       
        
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        passworddiv.Visible = true;

        
    }
    protected void Button3_Click(object sender, EventArgs e)

    {
          int vendorsno=VendorUtilities.GetVendorsno();
          String name, gender, email, userid, password, contact, address;

          name = txtname.Text;
          gender = txtgender.Text;
          email = txtemail.Text;

          userid = txtuser.Text;
          if (UserUtilities.CheckExistingUser(userid))
          {
              throw new Exception("Userid Already Exist");
          }

          password = txtpassword.Text;
            if(password.Equals(""))
            {
                throw new Exception("Please insert Password");
            }

          contact = txtcontactno.Text;
          address = txtcompanyaddress.Text;

          DataSet1TableAdapters.siteuserTableAdapter da = new DataSet1TableAdapters.siteuserTableAdapter();
          da.Insert(name, gender, email, userid, password, "" + contact, vendorsno, "Active", address);

          VendorUtilities.MakeVendorActive(sno);

          lblmain.Text = "Verified";
          Response.Redirect("index.aspx");


    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        Validations.totalResetTextboxs(txtuser,txtpassword);
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        VendorUtilities.RejectVendor(sno);
    }
}