﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;

public partial class Brandsentry : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btsubmit_Click(object sender, EventArgs e)
    {
        try
        {
            String Brand;

            Brand = txtbrandname.Text;
            string folder = Server.MapPath("brandimages\\"+Brand);
            string src = "";
            if (!Directory.Exists(folder))
                Directory.CreateDirectory(folder);
            if (!FileUpload1.Equals(null)&&!Brand.Trim().Equals("")&&!Brand.Equals(null))
            {
                FileUpload1.SaveAs(folder + "\\" + Brand);
                src = "brandimages/" + Brand + "/" + Brand;
            }
            else
                return;

            DataSet1TableAdapters.brandTableAdapter da = new DataSet1TableAdapters.brandTableAdapter();
            DataSet1.brandDataTable dt = da.GetDataByBrandName(Brand);
            if (dt.Rows.Count > 0)
                throw new Exception("Brand already Exists!!");
            da.Insert(Brand,src);
            Validations.setSuccess(lblmain, "Inserted Successfully!!");
            GridView1.DataBind();
           
        }
        catch (Exception x)
        {
            Validations.setError(lblmain, x.Message);
        }

    }
    
    protected void btreset_Click1(object sender, EventArgs e)
    {
        Validations.totalResetTextboxs(txtbrandname);
        Validations.totalResetLabels(lblmain);
    }
}