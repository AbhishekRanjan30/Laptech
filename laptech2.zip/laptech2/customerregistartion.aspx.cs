﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class vendorregistration : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void txtreset_Click(object sender, EventArgs e)
    {
        
    }
    protected void btnreg_Click(object sender, EventArgs e)
    {
        try
            {
        String name, gender, email, userid, password, address;
        int usertypeno = UserUtilities.GetUserSno();
        long contact = Convert.ToInt64(txtcontact.Text);

        name = txtname.Text;
        if (name.Equals(""))
        {
            throw new Exception("Please Enter Your name");
        }
        gender = rdgender.SelectedValue;
        if (gender.Equals(""))
        {
            throw new Exception("Please Select Your Gender");
        }
        
        email = txtemail.Text;
        if (email.Equals(""))
        {
            throw new Exception("Please Provide Your Email-ID");
        }
        bool b = Validations.IsEMail(email);
        if (!b)
        { 
            throw new Exception("Please enter valid email");
        }
        userid = txtuserid.Text;

        if (userid.Equals(""))
        {
            throw new Exception("Please Give Your User-ID");
        }

        if (UserUtilities.CheckExistingUser(userid))
        {
            throw new Exception("Userid Already Exist");
        }

        password = txtpassword.Text;
        if (password.Equals(""))
        {
            throw new Exception("Please insert Your password");
        }
        if (password.Length < 6)
        {
            throw new Exception("Password Should be greater than 6 Digits");
        }

       
        if (contact==0||contact==null)
        {
            throw new Exception("Please insert Your Contact");
        }

        if (contact < 5999999999||contact>9999999999)
        {
            throw new Exception("Please insert valid number");   
        }

        address = txtaddress.Text;
        if (address.Equals(""))
        {
            throw new Exception("Please insert Your Address");
        }

        DataSet1TableAdapters.siteuserTableAdapter da = new DataSet1TableAdapters.siteuserTableAdapter();
        da.Insert(name, gender, email, userid, password, "" + contact, usertypeno,"Active", address);

        Validations.setSuccess(lblmain, "Successfully Registered");
        LoginManager.DoLogin(userid, password, Session, Response);
          }

            catch(Exception x)
             {
                 Validations.setError(lblmain, x.Message);
             }
        }
}