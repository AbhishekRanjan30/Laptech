﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btsubmit_Click(object sender, EventArgs e)
    {
        try
        {

            string vendorname = txtvendorname.Text;
            if (vendorname.Equals(""))
            {
                throw new Exception("Please Enter Vendor Name");
            }

            DateTime dob = Convert.ToDateTime(txtdob.Text);
            
           if (dob.Equals(""))
            {
                 throw new Exception("Please Enter Vendor DOB");
            }

            string gender = txtgender.SelectedValue;
            if (gender.Equals(""))
            {
                 throw new Exception("Please Select Your Gender");
            }

            string state = txtstate.Text;
            if(state.Equals(""))
            {
                throw new Exception("Please Insert Your State");
            }

            long contact = Convert.ToInt64(txtcontactno.Text);
            if (contact.Equals(""))
            {
               throw new Exception("Please Enter Vendor Contact");
            }
            if (contact == 0 || contact == null)
            {
                throw new Exception("Please insert Your Contact");
            }

            if (contact < 5999999999 || contact > 9999999999)
            {
                throw new Exception("Please insert valid number");
            }

            string email = txtemail.Text;
            if (email.Equals(""))
            {
                throw new Exception("Please Enter Vendor Email");
            }
            bool b = Validations.IsEMail(email);
            if (!b)
            {
                throw new Exception("Please enter valid email");
            }

            string companyname = txtcompanyname.Text;
            if (companyname.Equals(""))
            {
                throw new Exception("Please Enter Vendor Company Name");
            }
            if(VendorUtilities.CheckExistingVendor(companyname))
            {
                throw new Exception("Company Already Exist");
            }

            string companyemail = txtcompanyemail.Text;
            if (companyemail.Equals(""))
            {
                throw new Exception("Please Enter Vendor company Email");
            }
            bool br = Validations.IsEMail(companyemail);
            if (!br)
            {
                throw new Exception("Please enter valid email");
            }

            long companycontactno = Convert.ToInt64(txtcompanycontactno.Text);
            if (companycontactno.Equals(""))
            {
                throw new Exception("Please Enter Vendor Company contact no");
            }
            if (companycontactno.Equals(""))
            {
                throw new Exception("Please Enter Vendor Contact");
            }
            if (companycontactno == 0 || companycontactno == null)
            {
                throw new Exception("Please insert Your Contact");
            }

            if (companycontactno < 5999999999 || companycontactno > 9999999999)
            {
                throw new Exception("Please insert valid number");
            }
            
            string companygstno = txtcompanygstno.Text;
            if (companygstno.Equals(""))
            {
                throw new Exception("Please Enter Vendor GST no");
            }
           
            string companyregno = txtcompanyregno.Text;
            if (companyregno.Equals(""))
            {
                throw new Exception("Please Enter Vendor Registration no");
            }
                
            string companyaddress = txtcompanyaddress.Text;
            if (companyaddress.Equals(""))
            {
                throw new Exception("Enter Company Address");
            }
            
            int defaultvendorno = VendorUtilities.GetDefaultVendorno();
            DataSet1TableAdapters.vendorappliedlistTableAdapter da = new DataSet1TableAdapters.vendorappliedlistTableAdapter();
            da.Insert(vendorname, dob+"", gender, state, ""+contact, email, companyname, companyaddress, companyemail,""+ companycontactno, companygstno, companyregno, "Pending", defaultvendorno);
            Validations.setSuccess(lblmain, "Successfully Registered");

            Response.Redirect("login.aspx");
        }
        catch (Exception x)
        {
            Validations.setError(lblmain, x.Message);
        }
    }
}