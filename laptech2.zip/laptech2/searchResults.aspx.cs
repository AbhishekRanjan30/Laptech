﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class searchResults : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string query = Request.QueryString["q"];
        if (query.Equals("") || query.Equals(null))
            Response.Redirect("index.aspx");
        string output = "";
        DataSet1TableAdapters.productsTableAdapter da = new DataSet1TableAdapters.productsTableAdapter();
        DataSet1.productsDataTable dt = da.GetSearchResult(query);
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            DataSet1.productsRow dr = (DataSet1.productsRow)dt.Rows[i];
            output += productdisplay.productsDiv(dr.sno,Session);
        }
        results.InnerHtml = output;
    }
}