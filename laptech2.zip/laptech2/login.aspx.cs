﻿ using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e) 
    {

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("siteuser.aspx");
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            string username = Txtusername.Text;
            string password = Txtpassword.Text;

            if (username.Trim().Equals("") || username.Trim().Equals(null))
            {
                throw new Exception("Plese Input Username !!!!");
            }

            if (password.Trim().Equals("") || password.Trim().Equals(null))
            {
                throw new Exception("Plese Input Password !!!!");
            }

            bool b = LoginManager.DoLogin(username, password, Session, Response);
            if (!b)
                throw new Exception("Invalid Username or Password");
        }
        catch(Exception x)
        {
            Validations.setError(lblmessage, x.Message);
        }
    }
}