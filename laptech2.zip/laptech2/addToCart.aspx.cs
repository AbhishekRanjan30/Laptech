﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class addToCart : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            int productNo = Convert.ToInt32(Request.QueryString["pno"]);
            if (!LoginManager.IsUserLoggedIn(Session))
            {
                Response.Write("Error");
                Response.Redirect("login.aspx");
            }
            else
            {
                DataSet1TableAdapters.cartTableAdapter da = new DataSet1TableAdapters.cartTableAdapter();
                da.Insert(productNo, UserUtilities.getSiteUserNo("" + Session["userid"]), 1, "InCart");
                
                int no = cartUtilities.getNoOfItemsInCart(Session);

                Response.Write("Success");
            }
        }
        catch (Exception ex)
        {
            Response.Write("Exception "+ex.Message);
            Response.Redirect("login.aspx");
        }
    }
}