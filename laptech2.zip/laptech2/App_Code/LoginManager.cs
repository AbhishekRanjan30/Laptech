﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.SessionState;

/// <summary>
/// Summary description for LoginManager
/// </summary>
public class LoginManager
{
    static string name;
    public static string vendorDashboard = "VendorDashBoard.aspx", adminDashBoard="adminDashBoard.aspx";
    public static bool IsUserNameandPasswordIsCorrect(String username, string password)
    {
        try
        {
            DataSet1TableAdapters.siteuserTableAdapter da = new DataSet1TableAdapters.siteuserTableAdapter();
            DataSet1.siteuserDataTable dt = da.GetDataByusernameandpassword(username, password);
            DataSet1.siteuserRow dr = (DataSet1.siteuserRow)dt.Rows[0];
            if (dt.Rows.Count <= 0)
                return false;
            if (!username.Equals(dr.userid))
                return false;
            if (!password.Equals(dr.password))
                return false;
            if (!dr.status.Equals("Active"))
            return false;

            name = dr.name;
            return true;
        }
        catch 
        {
            return false;
        }
    }

    public static bool DoLogin(string username, string password, HttpSessionState session, HttpResponse response)
    {
        try
        {
            bool b = IsUserNameandPasswordIsCorrect(username, password);
            if (!b)
                return false;
            session["userid"] = username;
            session["username"] = name;
            if(GetUserType(session).Equals("Admin")){
                response.Redirect(adminDashBoard);
            }
            else if (GetUserType(session).Equals("Vendor"))
            {
                response.Redirect(vendorDashboard);
            }
            else
            {
                response.Redirect("index.aspx");
            }
            return true;
        }
        catch
        {
            return false;
        }
    }
    public static String currentuser(HttpSessionState session)
    {
        if (session["username"] == null)
            return "";
        else
            return session["username"]+"";
    }
    public static bool IsUserLoggedIn(HttpSessionState session)
    {
        try
        {
            if (session["userid"] == null)
                return false;
            return true;
        }
        catch 
        {
            return false;
        }
    }
    public static void Dologout(HttpSessionState session, HttpResponse response)
    {
        try
        {
            session.Abandon();
            response.Redirect("login.aspx");
        }
        catch
        {

        }
    }

    public static string GetUserType(HttpSessionState session)
    {
        try
        {
            if (!IsUserLoggedIn(session))
            {
                throw new Exception("Please LogIn");
            }
            String userid = session["userid"]+"";
            DataSet1TableAdapters.usertypeTableAdapter da = new DataSet1TableAdapters.usertypeTableAdapter();
            DataSet1.usertypeDataTable dt = da.GetUsertypeByUserID(userid+"");
            DataSet1.usertypeRow dr=(DataSet1.usertypeRow)dt.Rows[0];
            return dr.usertype;
        }

        catch (Exception x)
        {
            return x.Message;
        }
    }
}