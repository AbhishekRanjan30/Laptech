﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for VendorUtilities
/// </summary>
public class VendorUtilities
{
    public static int GetDefaultVendorno()
    {
        DataSet1TableAdapters.siteuserTableAdapter da = new DataSet1TableAdapters.siteuserTableAdapter();
        int defaultno = (int)da.GetDefaultVendorsno();
        return defaultno;
    }

    public static int GetVendorsno()
    {
        DataSet1TableAdapters.usertypeTableAdapter da = new DataSet1TableAdapters.usertypeTableAdapter();
        int vendorsno = (int)da.GetVendorSerialNo();
        return vendorsno;
    }

    public static int GetlastSiteUserNo()
    {
        DataSet1TableAdapters.siteuserTableAdapter da = new DataSet1TableAdapters.siteuserTableAdapter();
        DataSet1.siteuserDataTable dr = da.GetData();
        DataSet1.siteuserRow dt = (DataSet1.siteuserRow)dr.Rows[0];
        return dt.sno;
    }

    public static void MakeVendorActive(int sno)
    {
        DataSet1TableAdapters.vendorappliedlistTableAdapter da = new DataSet1TableAdapters.vendorappliedlistTableAdapter();
        da.MakeVendorActive("Active", GetlastSiteUserNo(), sno);
    }

    public static void RejectVendor(int sno)
    {
        DataSet1TableAdapters.vendorappliedlistTableAdapter da = new DataSet1TableAdapters.vendorappliedlistTableAdapter();
        da.MakeVendorActive("Reject",GetDefaultVendorno(), sno);
    }
    public static int GetVendornobyname(String name)
    {
        DataSet1TableAdapters.vendorappliedlistTableAdapter da = new DataSet1TableAdapters.vendorappliedlistTableAdapter();
        DataSet1.vendorappliedlistDataTable dt = da.GetDataByName(name);
        DataSet1.vendorappliedlistRow dr = (DataSet1.vendorappliedlistRow)dt.Rows[0];
        return dr.sno;
    }
    public static bool CheckExistingVendor(string companyname)
    {
        DataSet1TableAdapters.vendorappliedlistTableAdapter da = new DataSet1TableAdapters.vendorappliedlistTableAdapter();
        DataSet1.vendorappliedlistDataTable dt = da.GetDataByCompanyName(companyname);
        if (dt.Rows.Count == 0)
        {
            return false;
        }
        else
            return true;
    }
}