﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.SessionState;

/// <summary>
/// Summary description for cartUtilities
/// </summary>
public class cartUtilities
{
	public cartUtilities()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public static int getNoOfItemsInCart(HttpSessionState session)
    {
        try
        {
            if (!LoginManager.IsUserLoggedIn(session))
                return 0;
            if (session["userid"].Equals("") || session["userid"].Equals(null))
                return 0;
            int userno = UserUtilities.getSiteUserNo(session["userid"] + "");
            DataSet1TableAdapters.cartTableAdapter da = new DataSet1TableAdapters.cartTableAdapter();
            DataSet1.cartDataTable dt = da.GetDataUserNoAndStatus(userno, "InCart");
            return dt.Rows.Count;
        }
        catch (Exception ex)
        {
            return 0;
        }
    }

    public static bool isProductInCart(int product,HttpSessionState session)
    {
        if(!LoginManager.IsUserLoggedIn(session))
            return false;
        int userno=UserUtilities.getSiteUserNo(session["userid"]+"");
        DataSet1TableAdapters.cartTableAdapter da = new DataSet1TableAdapters.cartTableAdapter();
        DataSet1.cartDataTable dt = da.GetDataByProductnoanduserno(product, userno);

        if (dt.Rows.Count != 0)
        {
            return true;
        }
        else
            return false;
    }

}