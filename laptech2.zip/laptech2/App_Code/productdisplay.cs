﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.SessionState;

/// <summary>
/// Summary description for productdisplay
/// </summary>
public class productdisplay
{
	public productdisplay()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public static string productsDiv(int productno,HttpSessionState session)
    {
        products p = new products(productno);

        String productname, brand;

        productname = p.modelno;
        brand = products.GetBrandNameByBrandNo(p.brandno);
        string output = "";
        string nameDiv = "<div class='w3-large'><b>"+brand+" "+productname+"</b></div><br />\n";
        string imageDiv = "<img class='zoom' src='"+products.GetDisplayImage(productno)+"' alt='product' height='150px'>\n";
        
        string priceDiv = "<div><br /><b> Rs. " +p.price+ "/-</b></div><br />\n";
        if (p.discount == 0)
        {
            priceDiv = "<div><b>Price <i class='fa fa-rupee-sign'></i> " + p.price + "</b><br /><br /></div>\n";
        }
        else
        {
            priceDiv = "<div><b>Price <i class='fa fa-rupee-sign'></i>" + (p.price - p.discount) + "&nbsp;&nbsp; <label style='text-decoration:line-through' class='w3-text-grey'><i class='fa fa-rupee-sign'></i>" + p.price + "</label></b><br /><br /></div>\n";
        }

        

        output = "<div class='w3-quarter w3-padding'><div class='w3-border w3-card-4 w3-round-large w3-padding '><a href='productdetails.aspx?pno=" + productno + "' style='text-decoration:none'><div class='w3-center' style=''>\n" + nameDiv + imageDiv + priceDiv + "</div></a>\n";
        output += "<div class='w3-row w3-center'><div id='btbuy"+productno+"' class='w3-button w3-col s5 w3-orange w3-hover-black w3-round-xlarge zoom'><i class='fa fa-rupee-sign'></i>&nbsp;<b>Buy Now</b></div>\n";
        if(cartUtilities.isProductInCart(productno,session))
            output += "<div id='btcart"+productno+"' class='w3-button w3-col s7 w3-green w3-hover-black w3-round-xlarge zoom'><i class='fa fa-check'></i>&nbsp;<b>Item In Cart</b></div></div></div></div>\n";
        else
            output += "<div id='btcart"+productno+"' onclick='addInCart("+productno+")' class='w3-button w3-col s7 w3-green w3-hover-black w3-round-xlarge zoom'><i class='fa fa-cart-plus'></i>&nbsp;<b>Add To Cart</b></div></div></div></div>\n";
        return output;
    }

    public static List<string> getAllImages(int productno)
    {
        List<string> imgList=new List<string>();
        DataSet1TableAdapters.productimageTableAdapter da = new DataSet1TableAdapters.productimageTableAdapter();
        DataSet1.productimageDataTable dt = da.GetDataByProductNo(productno);
        for (int x = 0; x < dt.Count; x++)
        {
            DataSet1.productimageRow dr = (DataSet1.productimageRow)dt.Rows[x];
            imgList.Add(dr.imageurl);
        }
        return imgList;
    }
}