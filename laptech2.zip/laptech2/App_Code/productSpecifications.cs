﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for productSpecifications
/// </summary>
public class productSpecifications
{
	public productSpecifications()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public static List<List<string>> GetProductSpecifications(int productno)
    {
        DataSet1TableAdapters.specifictaionsTableAdapter da = new DataSet1TableAdapters.specifictaionsTableAdapter();
        DataSet1.specifictaionsDataTable dt = da.GetDataByProductNo(productno);
        List<string> attributename = new List<string>();
        List<string> attributevalue = new List<string>();
        //List<List<string>> mainList=new List<
        for(int i=0;i<=dt.Rows.Count-1;i++)
        {
            DataSet1.specifictaionsRow dr = (DataSet1.specifictaionsRow)dt.Rows[i];
            string attname = dr.attributename;
            string attvalue = dr.attributevalue;
            attributename.Add(attname);
            attributevalue.Add(attvalue);
        }
        List<List<string>> main = new List<List<string>>();
        main.Add(attributename);
        main.Add(attributevalue);
        return main;
    }
}