﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for products
/// </summary>
public class products
{
    public int sno, brandno, vendorno;
    public float price, discount;
    public string modelno;
	public products(int sno)
	{
        DataSet1TableAdapters.productsTableAdapter da = new DataSet1TableAdapters.productsTableAdapter();
        DataSet1.productsDataTable dt = da.GetDataBySno(sno);
        DataSet1.productsRow dr = (DataSet1.productsRow)dt.Rows[0];

        sno = dr.sno;
        brandno = dr.brandno;
        vendorno = dr.vendorno;
        price =(float)dr.price;
        discount =(float)dr.discount;
        modelno = dr.modelno;
	}

    public static string GetBrandNameByBrandNo(int brandno)
    {
        DataSet1TableAdapters.brandTableAdapter da = new DataSet1TableAdapters.brandTableAdapter();
        DataSet1.brandDataTable dt = da.GetDataByBrandSno(brandno);
        DataSet1.brandRow dr = (DataSet1.brandRow)dt.Rows[0];

        return dr.brandname;
    }

    public static string GetDisplayImage(int productno)
    {
        DataSet1TableAdapters.productimageTableAdapter da = new DataSet1TableAdapters.productimageTableAdapter();
        DataSet1.productimageDataTable dt = da.GetDataByProductNo(productno);
        if (dt.Rows.Count == 0)
            return "";
        DataSet1.productimageRow dr = (DataSet1.productimageRow)dt.Rows[0];
        return dr.imageurl;
    }
}