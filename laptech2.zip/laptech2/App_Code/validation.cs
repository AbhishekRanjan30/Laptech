﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;
using System.Text.RegularExpressions;

/// <summary>
/// Summary description for validation
/// </summary>
public class Validations
{
    public static bool isInteger(object o)
    {
        try
        {
            Convert.ToInt32(o);
            return true;
        }
        catch
        {
            return false;
        }
    }
    public static void SetGreen(TextBox textboxes)
    {
        textboxes.CssClass.Replace("w3-red", "");
        textboxes.CssClass.Replace("w3-green", "");
        textboxes.CssClass += " w3-green ";
    }
    public static void SetGreen(params TextBox[] textboxes)
    {
        foreach (TextBox textbox in textboxes)
        {
            textbox.CssClass.Replace("w3-red", "");
            textbox.CssClass.Replace("w3-green", "");
        }
    }
    public static void setSuccess(Label lbl, string message)
    {
        lbl.CssClass = lbl.CssClass.Replace("w3-text-red", " ");
        lbl.CssClass += " w3-text-green ";
        lbl.Text = message;
    }
    public static void setSuccess(Label lbl, Exception ex)
    {
        setSuccess(lbl, ex.Message);
    }

    public static void setError(Label lbl, string message)
    {
        lbl.CssClass = lbl.CssClass.Replace("w3-text-green", " ");
        lbl.CssClass += " w3-text-red ";
        lbl.Text = message;
    }
    public static void setError(Label lbl, Exception ex)
    {
        setError(lbl, ex.Message);
    }
    public static void throwException(string message, params System.Web.UI.WebControls.TextBox[] textboxes)
    {
        foreach (System.Web.UI.WebControls.TextBox txt in textboxes)
        {
            txt.CssClass += "w3-red";
            throw new Exception(message);

        }
    }
    public static void totalResetTextboxs(params System.Web.UI.WebControls.TextBox[] textboxes)
    {
        foreach (TextBox txt in textboxes)
        {
            txt.Text = "";
            txt.CssClass = txt.CssClass.Replace("w3-red", "");
        }

    }
    public static void resetTextBoxes(params System.Web.UI.WebControls.TextBox[] textboxes)
    {
        foreach (TextBox txt in textboxes)
        {
            txt.CssClass = txt.CssClass.Replace("w3-red", "");
            txt.CssClass = txt.CssClass.Replace("w3-green", "");
        }
    }





    public static void makeLabelInVisible(params System.Web.UI.WebControls.Label[] labels)
    {
        foreach (Label lbl in labels)
        {

            lbl.CssClass = lbl.CssClass + " w3-hide ";

        }
    }



    public static void makeLabelVisible(params System.Web.UI.WebControls.Label[] labels)
    {
        foreach (Label lbl in labels)
        {

            lbl.CssClass = lbl.CssClass.Replace("w3-hide", "");

        }
    }

    public static void totalResetLabels(params System.Web.UI.WebControls.Label[] labels)
    {
        foreach (Label lbl in labels)
        {
            lbl.Text = "";
            lbl.CssClass = lbl.CssClass.Replace("w3-red", "");
            lbl.CssClass = lbl.CssClass.Replace("w3-green", "");
        }
    }


    public static string emailregularexpression = @"\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*";

    public static bool IsEMail(string email)
    {
        email = email.Trim();
        Regex regex = new Regex(Validations.emailregularexpression);
        MatchCollection collection = regex.Matches(email);
        if (collection.Count == 0)
            return false;
        string returnedemail = collection[0].Value.Trim();
        if (!email.Equals(returnedemail))
            return false;
        return true;
    }



}



