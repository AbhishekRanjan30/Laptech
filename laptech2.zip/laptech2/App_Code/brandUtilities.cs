﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for brandUtilities
/// </summary>
public class brandUtilities
{
	public brandUtilities()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    int sno;
    string brandname, brandimage;
    public static List<List<string>> GetAllBrands()
    {
        DataSet1TableAdapters.brandTableAdapter da = new DataSet1TableAdapters.brandTableAdapter();
        DataSet1.brandDataTable dt = da.GetData();
        List<string> brandname = new List<string>();
        List<string> brandimage = new List<string>();
        List<List<string>> main = new List<List<string>>();
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            DataSet1.brandRow dr = (DataSet1.brandRow)dt.Rows[i];
            string brndname = dr.brandname;
            string brndimage = dr.brandimage;

            brandname.Add(brndname);
            brandimage.Add(brndimage);
        }
        main.Add(brandname);
        main.Add(brandimage);
        return main;
    }
}