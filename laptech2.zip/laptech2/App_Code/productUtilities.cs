﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for productUtilities
/// </summary>
public class productUtilities
{
	public productUtilities()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public static int getLastProductNo()
    {
        DataSet1TableAdapters.productsTableAdapter da = new DataSet1TableAdapters.productsTableAdapter();
        DataSet1.productsDataTable dt = da.GetData();
        DataSet1.productsRow dr = (DataSet1.productsRow)dt.Rows[0];
        return dr.sno;
    }
}