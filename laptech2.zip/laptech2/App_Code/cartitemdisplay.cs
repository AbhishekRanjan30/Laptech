﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.SessionState;

/// <summary>
/// Summary description for cartitemdisplay
/// </summary>
public class cartitemdisplay
{
	public cartitemdisplay()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public static string cartItemDiv(HttpSessionState session)
    {
        int userno = UserUtilities.getSiteUserNo(session["userid"]+"");
        DataSet1TableAdapters.cartTableAdapter da = new DataSet1TableAdapters.cartTableAdapter();
        DataSet1.cartDataTable dt = da.GetDataUserNoAndStatus(userno, "InCart");
        string output="";
        for(int i=0;i<dt.Rows.Count;i++)
        {
            DataSet1.cartRow dr = (DataSet1.cartRow)dt.Rows[i];
            int productno = dr.productno;
            products pr = new products(productno);
            string productname = pr.modelno;
            string brand = products.GetBrandNameByBrandNo(pr.brandno);
            string displayimage = products.GetDisplayImage(productno);
            string displayprice = pr.price+"";
            string displaydiscount = pr.discount+"";
            
            List<List<string>> main = productSpecifications.GetProductSpecifications(productno);
            List<string> specsname = main[0];
            List<string> specsvalue = main[1];

            string specsname1 =  specsname[0];
            string specsname2="";
            if(specsname.Count>=1)
            specsname2 =  specsname[1];

            string specsvalue2="";
            string specsvalue1 =  specsvalue[0];
            if(specsvalue.Count>=1)
            specsvalue2 =  specsvalue[1];

            output += "<div class='w3-padding'>"+
                "<div class='w3-row w3-card-4'>"+
                    "<div class='w3-col s4 w3-center'>"+
                        "<img width='50%' src='" + displayimage + "' />"+
                    "</div>"+
                    "<div class='w3-col s8 w3-center w3-padding w3-row'><div class='w3-col s5'>"+
                        "<b>" + brand + "" + productname + "</b><br/>"
                        + specsname1 + " : " + specsvalue1 + "<br/>" + specsname2 + " : " + specsvalue2 + "<br/>" + 
                    "</div><div class='w3-col s7'>"+
                    "<div class='w3-button w3-col s4'>+</div><div class='w3-button w3-col s4'>5</div><div class='w3-button w3-col s4'>-</div>" +
                    "</div></div><br/></div></div>";
        }
        return output;
    }
}