﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for UserUtilities
/// </summary>
public class UserUtilities
{
    public static int GetUserSno()
    {
        DataSet1TableAdapters.usertypeTableAdapter da = new DataSet1TableAdapters.usertypeTableAdapter();
        int usersno = (int)da.GetUserSno();
        return usersno;
    }
    public static bool CheckExistingUser(String userid)
    {
        DataSet1TableAdapters.siteuserTableAdapter da = new DataSet1TableAdapters.siteuserTableAdapter();
        DataSet1.siteuserDataTable dt = da.GetDataByUserId(userid);
        if (dt.Rows.Count == 0)
        {
            return false;
        }
        else
            return true;
    }

    public static int getSiteUserNo(string userID)
    {
        DataSet1TableAdapters.siteuserTableAdapter da = new DataSet1TableAdapters.siteuserTableAdapter();
        DataSet1.siteuserDataTable dt = da.GetDataByUserId(userID);
        DataSet1.siteuserRow dr = (DataSet1.siteuserRow)dt.Rows[0];
        return dr.sno;
    }

}