﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MasterPage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        bool b = LoginManager.IsUserLoggedIn(Session);
        if (b)
        {
            btlogin.Visible = false;
            btlogout.Visible = true;
        }


        int cartItems = cartUtilities.getNoOfItemsInCart(Session);
        lblcartitemno.Text = cartItems + "";
    }
    protected void btlogin_Click(object sender, EventArgs e)
    {
        Response.Redirect("login.aspx");
    }
    protected void btlogout_Click(object sender, EventArgs e)
    {
        LoginManager.Dologout(Session, Response);
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        string query = txtSearch.Text;
        if (query.Equals("") || query.Equals(null))
            return;
        Response.Redirect("searchResults.aspx?q="+query);
    }
}
